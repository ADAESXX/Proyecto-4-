import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class WaveBullet here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class WaveBullet extends Actor
{
    int time = 0;
    int offsetX;
    
    public WaveBullet(int speedOffsetX){
        this.offsetX = speedOffsetX;
        
        GreenfootImage img = new GreenfootImage(10, 10);
        img.setColor(Color.CYAN);
        img.fillOval(0,0,10,10);
        setImage(img);
    }
    /**
     * Act - do whatever the WaveBullet wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        int dy = 4;
        int dx = (int)(Math.sin(time * 0.2) * 5) + offsetX;

        setLocation(getX() + dx, getY() + dy);
        time++;

        if (isAtEdge()) {
            getWorld().removeObject(this);
        }
    }
}
