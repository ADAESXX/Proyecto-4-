import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class spaceship here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Spaceship extends Actor
{
    
    private boolean canFire = true;
    private int lives = 3;
    
    public Spaceship(){
        GreenfootImage image = getImage();  
        image.scale(25, 25);
        setImage(image);
    }
    /**
     * Act - do whatever the spaceship wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        move();
        shoot();
        checkCollision();
    }
    
    public void move(){
        if (Greenfoot.isKeyDown("up")){
            setLocation(getX(), getY() - 5);
        }
        
        if (Greenfoot.isKeyDown("down")){
            setLocation(getX(), getY() + 5);
        }
        
        if (Greenfoot.isKeyDown("right")){
            move(8);
        }
        
        if (Greenfoot.isKeyDown("left")){
            move(-8);
        }
    }
    
    public void shoot(){
        if (Greenfoot.isKeyDown("x") && canFire == true){
            getWorld().addObject(new Laser(), getX(), getY());
            canFire = false;
        }
        
        else if(!Greenfoot.isKeyDown("x")){
            canFire = true;
        }
    }
    
    public void checkCollision() {
        Actor bullet = getOneIntersectingObject(EnemyBullet.class);
        if (bullet != null) {
            loseLife();
            getWorld().removeObject(bullet);
        }

        Actor wave = getOneIntersectingObject(WaveBullet.class);
        if (wave != null) {
            loseLife();
            getWorld().removeObject(wave);
        }

        Actor split = getOneIntersectingObject(SplittingBullet.class);
        if (split != null) {
            loseLife();
            getWorld().removeObject(split);
        }
        
    
    }
    
    public void setLives(int l) {
        this.lives = l;
    }
    
    public void loseLife() {
        lives--;

        if (lives <= 0) {
            die();
        }
    }
    
    public int getLives() {
        return lives;
    }

    public void die() {
        // Opcional: animación o sonido
        getWorld().removeObject(this);
        // También podrías agregar un Game Over screen aquí
        System.out.println("¡Game Over!");
    }
}
