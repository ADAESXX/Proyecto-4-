    import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
    
    /**
     * Write a description of class spaceship here.
     * 
     * @author (your name) 
     * @version (a version number or a date)
     */
    public class EnemySpaceship extends Actor
    {
        private int direction = 2;
        private int fireTimer = 0;
        private int spiralAngle = 0;
        private int difficulty;
        private int radialCooldown = 0;
        private static final int MAX_TOTAL_BULLETS = 200;
        private Healthbar bossBar;
        private int health;
        private Level currentLevel;

        public EnemySpaceship(int difficulty){
            this.difficulty = difficulty;
            this.health = 30 + difficulty * 10;
            this.bossBar = bossBar;
            
            GreenfootImage image = getImage();  
            image.scale(450, 450);
            setImage(image);
        }
    
        private boolean canFire = true;
        /**
         * Act - do whatever the spaceship wants to do. This method is called whenever
         * the 'Act' or 'Run' button gets pressed in the environment.
         */
        public void act()
        {
            move();
            shoot();
            checkDeath();
        }
        
        public void move(){
            if ((direction < 0 && getX() == 0) || (direction > 0 && getX() == getWorld().getWidth()-1)) direction = -direction;  
            move(direction);
        }
        
        public void shoot(){
            if (tooManyBullets()) return;
            fireTimer++;

            if (fireTimer % Math.max(2 - difficulty / 2, 1) == 0) {
            fireSpiral();
            }

            if (difficulty >= 2 && fireTimer % Math.max(30 - difficulty * 3, 8) == 0) {
            fireRadial();
            }

            if (difficulty >= 3 && fireTimer % 40 == 0) {
            int angle = Greenfoot.getRandomNumber(360);
            fireRandom(angle, 6 + difficulty);
            }

            if (difficulty >= 3 && fireTimer % 80 == 0) {
            fireSplitting();
            }

            if (difficulty == 4 && fireTimer % 30 == 0) {
            fireWave();
            }
        }
        
        public void fireRadial() {
            if (radialCooldown > 0) {
                radialCooldown--;
                return;
            }

            int bulletCount = 360 / (10 - difficulty);
    
            for (int i = 0; i < bulletCount; i++) {
                int angle = i * (10 - difficulty);
                EnemyBullet bullet = new EnemyBullet(angle, difficulty);
                getWorld().addObject(bullet, getX(), getY());
            }

            radialCooldown = 60 - difficulty * 10;
        }       
        
        public void fireSpiral() {
            EnemyBullet bullet = new EnemyBullet(spiralAngle, difficulty);
            getWorld().addObject(bullet, getX(), getY());
            spiralAngle = (spiralAngle + 10 + difficulty * 2) % 360;
        }
        
        public void fireRandom(int baseAngle, int count) {
            for (int i = 0; i < count; i++) {
                    int angle = baseAngle + Greenfoot.getRandomNumber(60) - 30;
                EnemyBullet bullet = new EnemyBullet(angle, difficulty);
                getWorld().addObject(bullet, getX(), getY());
            }
        }
        
        public void fireWave() {
            for (int i = -1; i <= 1; i++) {
            WaveBullet b = new WaveBullet(i * 2);
            getWorld().addObject(b, getX(), getY());
            }
        }
        
        public void fireSplitting(){
            SplittingBullet sb = new SplittingBullet();
            getWorld().addObject(sb, getX(), getY());    
        }
        
        public boolean tooManyBullets() {
            return getWorld().getObjects(Actor.class).stream().filter(a ->
            a instanceof EnemyBullet || a instanceof WaveBullet || a instanceof SplittingBullet
            ).count() >= MAX_TOTAL_BULLETS;
        }   
        
        public void takeDamage(int dmg) {
            health -= dmg;
            if (bossBar != null) {
                bossBar.update(health);
            }
        }
        
        public Healthbar getHealthbar() {
            return bossBar;
        }
        
        public void setHealthbar(Healthbar bar) {
            this.bossBar = bar;
        }      
        
        public void checkDeath() {
            
            if (health <= 0) {
                nextLevel();
                getWorld().removeObject(this);
            }
        }
        
        public void nextLevel() {
            World world = getWorld();
            if (world instanceof Level) {
                ((Level)world).startTransition(difficulty);
            } else {
            }
        }
    }
