import greenfoot.*; 

public class SplittingBullet extends Actor
{
    private int speed = 4;
    private int timeAlive = 0;
    private int splitAfter = 60;
    private boolean hasSplit = false;

    public SplittingBullet() {
        GreenfootImage img = new GreenfootImage(12, 12);
        img.setColor(Color.ORANGE);
        img.fillOval(0, 0, 12, 12);
        setImage(img);
    }

    public void act()
    {
        if (getWorld() == null) return;

        setLocation(getX(), getY() + speed);
        timeAlive++;

        if (isAtEdge() && !hasSplit) {
            hasSplit = true;
            if (getWorld() != null) getWorld().removeObject(this);
            return;
        }

        if (timeAlive >= splitAfter && !hasSplit) {
            split();
        }
    }

    public void split() {
        if (getWorld() == null) return;
        
        int baseAngle = 90;
        int[] angles = {-30, -15, 0, 15, 30};
        for (int a : angles) {
            EnemyBullet b = new EnemyBullet(baseAngle + a, 2);
            getWorld().addObject(b, getX(), getY());
        }

        hasSplit = true;

        Greenfoot.delay(1);
        if (getWorld() != null) getWorld().removeObject(this);
    
    }
}
