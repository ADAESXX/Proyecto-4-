import greenfoot.*;

public class TransitionScreen extends World {
    private World nextWorld;
    private boolean canProceed = false;

    public TransitionScreen(World nextWorld, String mensaje) {
        super(800, 600, 1);
        this.nextWorld = nextWorld;

        GreenfootImage text = new GreenfootImage(mensaje + " - Presiona 'Espacio' para continuar", 32, Color.WHITE, new Color(0, 0, 0, 128));
        getBackground().drawImage(text, getWidth()/2 - text.getWidth()/2, getHeight()/2 - text.getHeight()/2);
    }

    public void act() {
        if (Greenfoot.isKeyDown("space") && !canProceed) {
            canProceed = true;
            Greenfoot.setWorld(nextWorld);
        }

        if (!Greenfoot.isKeyDown("space")) {
            canProceed = false;
        }
    }
}



