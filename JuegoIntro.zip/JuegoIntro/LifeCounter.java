import greenfoot.*;

/**
 * Write a description of class LifeCounter here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class LifeCounter extends Actor
{
    private Spaceship player;

    public LifeCounter(Spaceship player) {
        this.player = player;
        updateImage();
    }

    public void act() {
        updateImage();
    }

    private void updateImage() {
        int vidas = player.getLives();
        GreenfootImage img = new GreenfootImage("Vidas: " + vidas, 24, Color.WHITE, new Color(0, 0, 0, 150));
        setImage(img);
    }
    /**
     * Act - do whatever the LifeCounter wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
}
