import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Level here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Level extends World
{
    private int bulletCount = 0;
    private final int MAX_BULLETS = 200;
    Spaceship player = new Spaceship();
    private EnemySpaceship boss;
    private Healthbar bossBar;

    /**
     * Constructor for objects of class Level.
     * 
     */
    public Level(int difficulty)
    {    
        super(600, 700, 1); 
        player = new Spaceship();
        player.setLives(3);
        prepareLevel(difficulty);
    }
    
    private void prepareLevel(int difficulty) {
        int bossHealth = 30 + difficulty * 10;

        boss = new EnemySpaceship(difficulty);
        bossBar = new Healthbar(bossHealth);
        boss.setHealthbar(bossBar);

        addObject(boss, getWidth() / 2, 150);
        addObject(bossBar, getWidth() / 2, 10);
    }

    
    public boolean canAddBullet() {
        return bulletCount < MAX_BULLETS;
    }
    
    public void registerBullet() {
        bulletCount++;
    }
    
    public void unregisterBullet() {
        bulletCount = Math.max(0, bulletCount - 1);
    }
    
    public void startTransition(int difficulty) {        
        World nextLevel;

    if (difficulty == 1) {
        nextLevel = new Level2();
    } else if (difficulty == 2) {
        nextLevel = new Level3();
    } else if (difficulty == 3) {
        nextLevel = new Level4();
    } else {
        nextLevel = new VictoryScreen();
    }

    Greenfoot.setWorld(new TransitionScreen(nextLevel, "Nivel " + (difficulty + 1)));
    }
}
