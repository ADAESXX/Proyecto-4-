import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Laser here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Laser extends Actor
{
    /**
     * Act - do whatever the Laser wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    private int bulletSpeed = 5;
    
    public void addedToWorld(World Latar){
        GreenfootImage image = new GreenfootImage(50,50);
        image.setColor(Color.RED);
        image.drawLine(5,0,5,image.getHeight()-1);
        setImage(image);
    }
    public void act()
    {
        move();
        removeBullet();
    }
    
    public void move(){
        setLocation(getX(), getY()-bulletSpeed);
    }
    
    public void removeBullet(){
        if(getY() <= 5 || getY() >= getWorld().getHeight()-5){
            getWorld().removeObject(this);
        }
    }
}
