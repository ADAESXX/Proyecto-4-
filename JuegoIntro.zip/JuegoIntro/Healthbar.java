import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Write a description of class Healthbar here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Healthbar extends Actor
{
    private int maxHealth;
    int healthBarWidth = 600;
    int healthBarHeight = 15;
    /**
     * Act - do whatever the Healthbar wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    public Healthbar(int maxHealth) {
        this.maxHealth = maxHealth;
        update(maxHealth); // Al iniciar, se muestra llena
    }
    
    public void act(){
    }
    
    public void update(int currentHealth) {
        if (currentHealth < 0) currentHealth = 0;
        int pixelsPerHealthPoint = (int)((double)healthBarWidth / maxHealth);
        setImage(new GreenfootImage(healthBarWidth + 2, healthBarHeight + 2));
        GreenfootImage myImage = getImage();
        myImage.setColor(Color.WHITE);
        myImage.drawRect(0, 0, healthBarWidth + 1, healthBarHeight + 1);
        myImage.setColor(Color.RED);
        myImage.fillRect(1, 1, currentHealth * pixelsPerHealthPoint, healthBarHeight);
    }

}