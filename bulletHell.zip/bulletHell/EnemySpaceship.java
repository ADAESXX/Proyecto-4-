import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class spaceship here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class EnemySpaceship extends Actor
{
    private int direction = 2;
    
    public EnemySpaceship(){
        GreenfootImage image = getImage();  
        image.scale(600, 600);
        setImage(image);
    }

    private boolean canFire = true;
    /**
     * Act - do whatever the spaceship wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        move();
        shoot();
    }
    
    public void move(){
        // checking edges  
        if ((direction < 0 && getX() == 0) || (direction > 0 && getX() == getWorld().getWidth()-1)) direction = -direction;  
        // movement  
        move(direction);
    }

    
    public void shoot(){
        
    }
}
