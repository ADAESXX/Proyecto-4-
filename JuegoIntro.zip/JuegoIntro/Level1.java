import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Level1 extends Level
{
    private int bulletCount = 0;
    private final int MAX_BULLETS = 200;
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public Level1()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1); 
        Greenfoot.setSpeed(47);
        
        Spaceship player = new Spaceship();
        addObject(player, getWidth()/2, getHeight() - 50);

        LifeCounter lifeCounter = new LifeCounter(player);
        addObject(lifeCounter, 70, 30);
    }

    public boolean canAddBullet() {
        return bulletCount < MAX_BULLETS;
    }
    
    public void registerBullet() {
        bulletCount++;
    }
    
    public void unregisterBullet() {
        bulletCount = Math.max(0, bulletCount - 1);
    }
}
