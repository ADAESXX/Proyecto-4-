import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Level2 extends Level
{
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public Level2(){
        super(2);
        Greenfoot.setSpeed(47);
        
        Spaceship player = new Spaceship();
        addObject(player, getWidth()/2, getHeight() - 50);

        LifeCounter lifeCounter = new LifeCounter(player);
        addObject(lifeCounter, 70, 30);
    }

}
