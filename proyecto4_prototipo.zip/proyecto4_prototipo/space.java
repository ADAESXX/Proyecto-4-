import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class space here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class space extends World
{
    //variables globales 
    //tiempo en pantalla del mensaje
    int tiempovisiblemensaje=100;
    //saber si ya se inicia el juego o no
    boolean inicio=false;
    private mensaje_inicio mensaje;

    /**
     * Constructor for objects of class space.
     * 
     */
    public space()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        //variables para agregar el mensaje de incio del juego
        mensaje=new mensaje_inicio();
        addObject(mensaje, getWidth()/2, getHeight()/2);
    }
    public void act(){
        //si no se 
        if(!inicio){
            tiempovisiblemensaje--;
            if (tiempovisiblemensaje <= 0) {
                removeObject(mensaje);
                IniciarJuego();
                inicio=true;
            }
        }
    }
    public void IniciarJuego(){
        //agregar personajes
        nave personaje =new nave();
        //se posiciona centrado hasta abajo
        addObject(personaje, getWidth() / 2, getHeight() - 30);
        //se posicionan 5 aleatoriamente en la parte superior de la pantalla
        for (int i = 0; i < 5; i++) {
            enemigo enemigo = new enemigo();
            //el 50 para representar los margenes
            int x = Greenfoot.getRandomNumber(getWidth()-2*50);
            int y = Greenfoot.getRandomNumber(getHeight() / 2 -2*50);
            addObject(enemigo, x, y);
        }
        
    }
}
