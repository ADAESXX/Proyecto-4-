import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class TransitionTrigger here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TransitionTrigger extends Actor {
    private int difficulty;
    private int timer = 0;

    public TransitionTrigger(int difficulty) {
        this.difficulty = difficulty;

        GreenfootImage img = new GreenfootImage(10, 10);
        img.setColor(new Color(0, 0, 0, 0)); // totalmente transparente
        img.fillRect(0, 0, 10, 10);
        setImage(img);
    }

    public void act() {
        timer++;

        if (timer == 100) {
            switch (difficulty + 1) {
                case 1:
                Greenfoot.setWorld(new Level1());
                break;
                case 2:
                Greenfoot.setWorld(new Level2());
                break;
                case 3:
                Greenfoot.setWorld(new Level3());
                break;
                case 4:
                Greenfoot.setWorld(new Level4());
                break;
                default:
                Greenfoot.setWorld(new VictoryScreen());
                break;
            }
        }
    }
}

