import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Laser here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Laser extends Actor
{
    /**
     * Act - do whatever the Laser wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    private int bulletSpeed = 5;
    
    public void addedToWorld(World Latar){
        GreenfootImage image = new GreenfootImage(10, 10);
        image.setColor(Color.RED);
        image.fillOval(0, 0, 10, 10);
        setImage(image);
    }
    public void act()
    {
        move();
        removeBullet();
        if (getWorld() != null) {
            collisionDetect();
        }
    }
    
    public void move(){
        setLocation(getX(), getY()-bulletSpeed);
    }
    
    public void removeBullet(){
        if(getY() <= 5 || getY() >= getWorld().getHeight()-5){
            getWorld().removeObject(this);
        }
    }
    
    public void collisionDetect(){
        EnemySpaceship enemy = (EnemySpaceship) getOneIntersectingObject(EnemySpaceship.class);
        if (enemy != null) {
        enemy.takeDamage(1);
        getWorld().removeObject(this);
    }
    }
}
