import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class spaceship here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Spaceship extends Actor
{
    private boolean canFire = true;
    /**
     * Act - do whatever the spaceship wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        move();
        shoot();
    }
    
    public void move(){
        if (Greenfoot.isKeyDown("up")){
            setLocation(getX(), getY() - 5);
        }
        
        if (Greenfoot.isKeyDown("down")){
            setLocation(getX(), getY() + 5);
        }
        
        if (Greenfoot.isKeyDown("right")){
            move(8);
        }
        
        if (Greenfoot.isKeyDown("left")){
            move(-8);
        }
    }
    
    public void shoot(){
        if (Greenfoot.isKeyDown("x") && canFire == true){
            getWorld().addObject(new Laser(), getX(), getY());
            canFire = false;
        }
        
        else if(!Greenfoot.isKeyDown("x")){
            canFire = true;
        }
    }
}
