import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class VictoryScreen here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class VictoryScreen extends World {
    public VictoryScreen() {
        super(800, 600, 1);
        showText("¡Has ganado el juego!", getWidth() / 2, getHeight() / 2);
        showText("Presiona 'ESC' para salir", getWidth() / 2, getHeight() / 2 + 30);
        setBackground(new GreenfootImage("black"));
    }
    public void act() {
            if (Greenfoot.isKeyDown("escape")) {
                Greenfoot.stop();
            }
        }
}
